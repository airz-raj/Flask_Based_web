import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters, ConversationHandler
from transformers import pipeline
import sqlite3

# Set up logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize NLP pipeline
nlp = pipeline("conversational")

# Database connection
conn = sqlite3.connect('bot.db', check_same_thread=False)
cursor = conn.cursor()

# Create table to store user data
cursor.execute('''CREATE TABLE IF NOT EXISTS user_data (user_id INTEGER PRIMARY KEY, user_name TEXT)''')
conn.commit()

# Define states for ConversationHandler
NAME, AGE = range(2)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    user_name = update.message.from_user.username

    cursor.execute("INSERT OR IGNORE INTO user_data (user_id, user_name) VALUES (?, ?)", (user_id, user_name))
    conn.commit()

    await update.message.reply_text('Hello! I am your bot. How can I help you?')
    logger.info("Start command received from user: %s", user_name)
    return ConversationHandler.END

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text('Here is how you can use this bot...')
    logger.info("Help command received")

async def echo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_message = update.message.text
    logger.info("Message received: %s", user_message)
    result = nlp(user_message)
    bot_response = result[0]['generated_text']
    await update.message.reply_text(bot_response)
    logger.info("Bot response sent: %s", bot_response)

async def start_conversation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text('Hello! What is your name?')
    return NAME

async def get_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_name = update.message.text
    context.user_data['name'] = user_name
    await update.message.reply_text(f'Nice to meet you, {user_name}. How old are you?')
    return AGE

async def get_age(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_age = update.message.text
    await update.message.reply_text(f'Thank you, {context.user_data["name"]}. You are {user_age} years old.')
    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text('Conversation canceled.')
    return ConversationHandler.END

def main():
    # Create the application
    app = ApplicationBuilder().token("6809136961:AAFrMDqcvPVTqp0LSTimCjlRj_-3mWcl7U8").build()

    # Register handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))

    # Add conversation handler
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start_conversation', start_conversation)],
        states={
            NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_name)],
            AGE: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_age)],
        },
        fallbacks=[CommandHandler('cancel', cancel)]
    )
    app.add_handler(conv_handler)

    # Run the bot
    app.run_polling()

if __name__ == '__main__':
    main()
