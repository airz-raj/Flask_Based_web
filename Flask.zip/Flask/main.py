from flask import Flask, render_template
app = Flask(__name__)
@app.route("/")
def home():
    return render_template('index.html')
@app.route("/charts")
def charts():
    return render_template("charts.html")
@app.route("/tables")
def tables():
    return render_template("tables.html")
app.run(debug=True)
